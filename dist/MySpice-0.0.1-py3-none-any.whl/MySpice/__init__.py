name = "example_pkg" 

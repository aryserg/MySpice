name = "MySpice" 
from . import MySpice
